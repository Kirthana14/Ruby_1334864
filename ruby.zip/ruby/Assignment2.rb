def encrypt(str,n)

atoz=('A'..'Z').to_a 
ctext=""
ctmp=str.tr('A-Z',(atoz[n..25]<< atoz[0...n]).flatten.join).tr('0-9',('0'..'9').to_a.reverse.join)
ctmp.each_char.with_index {|c,i|
if i.even?
ctext << c.upcase
else
ctext << c.downcase
end
}
ctext.reverse
end
p encrypt("HI THIS IS RUBY ON RAILS 123!!!",1)
